<template>
  <div id="app">
    <!-- <router-link to="/h1">1212</router-link> -->
  
    <router-view></router-view>
  </div>
</template>
<script src="//unpkg.com/vue-ydui/dist/ydui.flexible.js"></script>
<script>
export default {
  active: 0
};
</script>

<style>
html,
body {
  background: #fff;
  height: 100%;
  /* font-size:16px; */
}

</style>
